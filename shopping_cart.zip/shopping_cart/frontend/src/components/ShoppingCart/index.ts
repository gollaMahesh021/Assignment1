import ShoppingCart from './ShoppingCart';

export default ShoppingCart;
