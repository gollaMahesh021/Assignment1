export default {
  apiUrl: process.env.API_URL,
};
